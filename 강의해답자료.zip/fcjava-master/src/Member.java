// 회원(Object) : [이름, 나이, 전화번호, 이메일, 거주지, 몸무게], 키,,,,,,,,
public class Member {
    public String name;
    public int age;
    public String tel;
    public String email;
    public String addr;
    public float weight;
}
