public class FindAPI {
    public static void main(String[] args) {
        int a; //변수선언
        // AAA b;
        a=10;
        System.out.println("a = " + a);
        // "APPLE" 문자열 저장하고 출력
        String s;
        s="APPLE";
        System.out.println("s = " + s);
        System.out.println(s.length());

    }
}
