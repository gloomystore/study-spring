// 책(Object) : 제목, 가격, 출판사, 저자, 페이지수, isbn .........
// class : 새로운 자료형을 설계하는 도구(Modeling)
public class Book {
    public String title;
    public int price;
    public String company;
    public String author;
    public int page;
    public String isbn;
}
