package fc.java.model;

public class MyUtil {
   public static int hap(int a, int b){
       int v=a+b;
       return v;
   }
}

