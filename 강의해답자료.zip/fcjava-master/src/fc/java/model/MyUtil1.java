package fc.java.model;

public class MyUtil1 {
    public int hap(int a, int b){
        int v=a+b;
        return v;
    }
}
