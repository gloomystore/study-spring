package fc.java.part3; // package 선언문
// fc.java.part3.BookDTO : 클래스의 풀이름(fullname)
public class BookDTO {
    public String title;
    public int price;
    public String company;
    public String author;
    public int page;
    public String isbn;
}
