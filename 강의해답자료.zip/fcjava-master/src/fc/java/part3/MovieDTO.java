package fc.java.part3;

public class MovieDTO {
    // 상태정보, 멤버변수, 속성, 프로퍼티(*)
    public String title;
    public int day;
    public String major;
    public String part;
    public float time;
    public int level;
}
