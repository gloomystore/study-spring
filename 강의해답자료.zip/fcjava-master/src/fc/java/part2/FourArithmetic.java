package fc.java.part2;

public class FourArithmetic {
    public static void main(String[] args) {
        //두 개의 정수를 사칙연산(+,-,*,/)하여 출력하는 JavaSE프로그램을 만들어보자.
        int a, b;
        a=12;
        b=2;
        System.out.println("a+b="+(a+b)); // a+b=14
        System.out.println("a-b="+(a-b));
        System.out.println("a*b="+(a*b));
        System.out.println("a/b="+(a/b));
    }
}
