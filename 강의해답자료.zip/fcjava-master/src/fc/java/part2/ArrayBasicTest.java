package fc.java.part2;

public class ArrayBasicTest {
    public static void main(String[] args) {
       // Q. [정수 30개]를 저장 할 [변수를 선언]하고 모두 10을 저장하세요.
       // 데이터의 수가 늘어나면
       // 데이터처리가 복잡
       int a,b,c;
       a=10;
       b=10;
       c=10;
       int sum=a+b+c;
        System.out.println("sum = " + sum);
    }
}
