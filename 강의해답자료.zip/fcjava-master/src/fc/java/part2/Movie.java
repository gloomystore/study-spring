package fc.java.part2;

// 영화(Object) -> 제목, 개봉일, 주인공, 장르, 러닝타임, 등급........
public class Movie {
    public String mtitle;
    public String mday;
    public String mmajor;
    public String mpart;
    public int mtime;
    public int mlevel;
}
