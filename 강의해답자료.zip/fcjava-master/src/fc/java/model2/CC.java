package fc.java.model2;
// CC는 노출
public interface CC {
    public void x();
    public void y();
    public void z();
}
