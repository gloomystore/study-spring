package fc.java.model2;

public class A {
    public void display(){
        System.out.println("나는 A이다.");
    }
}
