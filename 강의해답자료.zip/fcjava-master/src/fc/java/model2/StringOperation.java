package fc.java.model2;
@FunctionalInterface
public interface StringOperation {
    public String apply(String s);
}
