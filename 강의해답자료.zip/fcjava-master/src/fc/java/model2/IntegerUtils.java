package fc.java.model2;

public class IntegerUtils {
    // 정적메서드, 클래스메서드
    public static int stringToInt(String s){
        return Integer.parseInt(s); //"100"-->100
    }
}
