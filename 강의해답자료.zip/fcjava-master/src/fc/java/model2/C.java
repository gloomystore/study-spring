package fc.java.model2;

public class C {
    public void display(){
        System.out.println("나는 C이다.");
    }
}
