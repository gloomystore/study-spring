package fc.java.poly;
import java.lang.*;
public class A extends Object{
    public A(){
        super(); // new Object()
    }
    public void display(){
        System.out.println("나는 A 입니다.");
    }
    public void printGo(){
        System.out.println("나는 A 입니다.");
    }
}
