package fc.java.poly;
// 추상클래스=추상메서드+구현메서드
public interface RemoCon {
    //chUp(), chDown(), volUp(), VolDown()
    public void chUp();
    public void chDown();
    public void volUp();
    public void volDown();
    public void internet();
}
