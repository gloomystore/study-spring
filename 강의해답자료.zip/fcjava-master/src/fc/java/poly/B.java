package fc.java.poly;

public class B {
    public void printGo(){
        System.out.println("나는 B 입니다.");
    }
}
